//
//  File.swift
//  
//
//  Created by Najmi Antariksa on 26.06.23.
//

import Foundation

struct PaymentDTO: Codable {
    var paypalTransactionId: String
}
